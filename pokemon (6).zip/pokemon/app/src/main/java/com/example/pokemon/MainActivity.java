package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<pokemon> pokemons = new ArrayList<>();
        pokemon p = new pokemon("venusaur",R.drawable.venusaur,200,400,699);
        pokemon a = new pokemon("bulbasaur",R.drawable.bulbasaur,300,200,500);
        pokemon c = new pokemon("charizard",R.drawable.charizard,100,200,300);
        pokemon s = new pokemon("squirlte",R.drawable.sandslash,200,400,600);
        pokemon vc = new pokemon("sandslash",R.drawable.sandslash,20,100,120);

        pokemons.add(p);
        pokemons.add(a);
        pokemons.add(c);
        pokemons.add(s);
        pokemons.add(vc);
        RecyclerView x = findViewById(R.id.re);
        x.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        x.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        x.setLayoutManager(lm);

        pokemonAdapter pa = new pokemonAdapter(pokemons,this);
        x.setAdapter(pa);

    }
}